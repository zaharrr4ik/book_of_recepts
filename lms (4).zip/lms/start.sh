#!/bin/bash
# Скрипт запуска приложения с Tuna

# Устанавливаем зависимости
pip install -r requirements.txt

# Запускаем Flask в фоновом режиме
python app.py &

# Даем серверу время на запуск
sleep 2

# Запускаем Tuna
tuna http 5000

# Для остановки: Ctrl+C и затем pkill -f "python app.py"