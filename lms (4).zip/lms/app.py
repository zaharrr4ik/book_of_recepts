import os
import uuid
from datetime import datetime, timezone


from flask import (
    Flask, render_template, request, redirect,
    url_for, flash, abort
)
from flask_login import (
    LoginManager, UserMixin, login_user,
    logout_user, login_required, current_user
)
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func
from werkzeug.security import generate_password_hash, check_password_hash

# Инициализация Flask приложения
app = Flask(__name__)

# Настройка конфигурации приложения
app.config['SECRET_KEY'] = 'your-secret-key-here'  # Секретный ключ для защиты сессий и форм
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(
    os.path.abspath(os.path.dirname(__file__)), 'site.db'
)  # Путь к базе данных SQLite
app.config['UPLOAD_FOLDER'] = os.path.join('static', 'uploads')  # Папка для хранения загруженных файлов (фото блюд)
app.config['AVATARS_FOLDER'] = os.path.join(app.config['UPLOAD_FOLDER'],
                                            'avatars')  # Подпапка для аватаров пользователей
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  # Отключение отслеживания изменений для оптимизации

# Создание директорий для загрузок, если они еще не существуют
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['AVATARS_FOLDER'], exist_ok=True)

# Инициализация объекта базы данных
db = SQLAlchemy(app)

# Инициализация менеджера авторизации
login_manager = LoginManager(app)
login_manager.login_view = 'login'  # Указывает маршрут для перенаправления неавторизованных пользователей


# Модель пользователя, наследуется от UserMixin для поддержки Flask-Login
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)  # Уникальный идентификатор пользователя
    username = db.Column(db.String(30), unique=True, nullable=False)  # Имя пользователя, уникальное
    password_hash = db.Column(db.String(128), nullable=False)  # Хэш пароля
    avatar = db.Column(db.String(100), default='default_avatar.jpg')  # Путь к файлу аватара
    is_admin = db.Column(db.Boolean, default=False)  # Флаг администратора
    dishes = db.relationship('Dish', backref='author', lazy=True, cascade='all, delete-orphan')  # Связь с блюдами
    comments = db.relationship('Comment', backref='user', lazy=True,
                               cascade='all, delete-orphan')  # Связь с комментариями


# Модель блюда
class Dish(db.Model):
    id = db.Column(db.Integer, primary_key=True)  # Уникальный идентификатор блюда
    name = db.Column(db.String(50), nullable=False)  # Название блюда
    photo = db.Column(db.String(100))  # Путь к фото блюда
    ingredients = db.Column(db.Text, nullable=False)  # Список ингредиентов
    recipe_steps = db.Column(db.Text, nullable=False)  # Шаги рецепта
    calories = db.Column(db.Integer)  # Калорийность (опционально)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)  # ID автора блюда
    ratings = db.relationship('Rating', backref='dish', lazy=True, cascade='all, delete-orphan')  # Связь с рейтингами
    comments = db.relationship('Comment', backref='dish', lazy=True,
                               cascade='all, delete-orphan')  # Связь с комментариями
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))  # Дата создания


# Модель комментария
class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)  # Уникальный идентификатор комментария
    text = db.Column(db.Text, nullable=False)  # Текст комментария
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)  # ID автора комментария
    dish_id = db.Column(db.Integer, db.ForeignKey('dish.id'), nullable=False)  # ID блюда
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))  # Дата создания


# Модель рейтинга
class Rating(db.Model):
    id = db.Column(db.Integer, primary_key=True)  # Уникальный идентификатор рейтинга
    value = db.Column(db.Integer, nullable=False)  # Значение рейтинга (1-5)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)  # ID пользователя
    dish_id = db.Column(db.Integer, db.ForeignKey('dish.id'), nullable=False)  # ID блюда
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))  # Дата создания


# Функция загрузки пользователя для Flask-Login
@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))  # Возвращает объект пользователя по ID


# Проверка допустимых расширений файлов для загрузки
def allowed_file(filename):
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}  # Допустимые форматы изображений
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


# Главная страница - перенаправление на страницу входа
@app.route('/')
def home():
    return redirect(url_for('login'))


# Страница входа в систему
@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:  # Если пользователь уже авторизован
        return redirect(url_for('index'))  # Перенаправление на главную страницу
    if request.method == 'POST':  # Обработка формы входа
        username = request.form.get('username')  # Получение имени пользователя
        password = request.form.get('password')  # Получение пароля
        user = User.query.filter_by(username=username).first()  # Поиск пользователя в базе
        if user and check_password_hash(user.password_hash, password):  # Проверка пароля
            login_user(user)  # Вход пользователя
            return redirect(url_for('index'))  # Перенаправление на главную страницу
        flash('Неверные учетные данные', 'danger')  # Сообщение об ошибке
    return render_template('login.html')  # Отображение формы входа


# Страница регистрации
@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:  # Если пользователь уже авторизован
        return redirect(url_for('index'))
    if request.method == 'POST':  # Обработка формы регистрации
        username = request.form.get('username')
        password = request.form.get('password')
        if User.query.filter_by(username=username).first():  # Проверка уникальности имени
            flash('Этот логин уже занят', 'danger')
            return redirect(url_for('register'))
        try:
            filename = 'default_avatar.jpg'  # Аватар по умолчанию
            if 'avatar' in request.files:  # Если загружен аватар
                avatar = request.files['avatar']
                if avatar and allowed_file(avatar.filename):  # Проверка формата
                    filename = f"{uuid.uuid4()}.{avatar.filename.rsplit('.', 1)[1].lower()}"  # Уникальное имя файла
                    avatar.save(os.path.join(app.config['AVATARS_FOLDER'], filename))  # Сохранение аватара
            user = User(
                username=username,
                password_hash=generate_password_hash(password),  # Хэширование пароля
                avatar=filename
            )
            db.session.add(user)  # Добавление пользователя в сессию
            db.session.commit()  # Сохранение в базе
            login_user(user)  # Автоматический вход
            return redirect(url_for('index'))
        except Exception as e:
            db.session.rollback()  # Откат при ошибке
            flash(f'Ошибка регистрации: {str(e)}', 'danger')
    return render_template('register.html')  # Отображение формы регистрации


# Страница профиля пользователя
@app.route('/profile/<username>')
@login_required
def profile(username):
    user = User.query.filter_by(username=username).first_or_404()  # Поиск пользователя или ошибка 404
    return render_template('profile.html', user=user)  # Отображение профиля


# Редактирование профиля (смена аватара)
@app.route('/edit_profile', methods=['GET', 'POST'])
@login_required
def edit_profile():
    if request.method == 'POST':
        try:
            if 'avatar' in request.files:
                avatar = request.files['avatar']
                if avatar and allowed_file(avatar.filename):
                    if current_user.avatar != 'default_avatar.jpg':  # Удаление старого аватара
                        old_path = os.path.join(app.config['AVATARS_FOLDER'], current_user.avatar)
                        if os.path.exists(old_path):
                            os.remove(old_path)
                    filename = f"{uuid.uuid4()}.{avatar.filename.rsplit('.', 1)[1].lower()}"
                    avatar.save(os.path.join(app.config['AVATARS_FOLDER'], filename))
                    current_user.avatar = filename  # Обновление аватара
            db.session.commit()
            flash('Профиль обновлен', 'success')
            return redirect(url_for('profile', username=current_user.username))
        except Exception as e:
            db.session.rollback()
            flash(f'Ошибка обновления: {str(e)}', 'danger')
    return render_template('edit_profile.html')


# Главная страница с списком блюд
@app.route('/index')
@login_required
def index():
    dishes = db.session.query(
        Dish,
        func.count(Comment.id).label('comments_count'),  # Количество комментариев
        func.round(func.coalesce(func.avg(Rating.value), 0.0), 1).label('avg_rating')  # Средний рейтинг
    ).outerjoin(Comment, Dish.id == Comment.dish_id
                ).outerjoin(Rating, Dish.id == Rating.dish_id
                            ).group_by(Dish.id).all()  # Группировка по блюдам
    return render_template('index.html', dishes=dishes)


# Добавление нового блюда
@app.route('/add', methods=['GET', 'POST'])
@login_required
def add_dish():
    if request.method == 'POST':
        try:
            calories_str = request.form.get('calories', '0').strip()
            calories = int(calories_str) if calories_str else 0  # Обработка калорий
            file = request.files['photo']
            if file.filename == '':
                raise ValueError("Не выбрано изображение")
            if not allowed_file(file.filename):
                raise ValueError("Недопустимый формат файла")
            filename = f"{uuid.uuid4()}.{file.filename.rsplit('.', 1)[1].lower()}"
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            dish = Dish(
                name=request.form['name'],
                photo=filename,
                ingredients=request.form['ingredients'],
                recipe_steps=request.form['recipe_steps'],
                calories=calories,
                user_id=current_user.id
            )
            db.session.add(dish)
            db.session.commit()
            flash('Блюдо успешно добавлено!', 'success')
            return redirect(url_for('index'))
        except Exception as e:
            db.session.rollback()
            flash(f'Ошибка: {str(e)}', 'danger')
    return render_template('add_dish.html')


# Удаление блюда
@app.route('/delete_dish/<int:dish_id>', methods=['POST'])
@login_required
def delete_dish(dish_id):
    try:
        dish = Dish.query.get_or_404(dish_id)
        if dish.user_id != current_user.id and not current_user.is_admin:  # Проверка прав
            abort(403)
        if dish.photo:  # Удаление фото блюда
            try:
                os.remove(os.path.join(app.config['UPLOAD_FOLDER'], dish.photo))
            except Exception as e:
                app.logger.error(f"Ошибка удаления файла: {str(e)}")
        db.session.delete(dish)
        db.session.commit()
        flash('Блюдо успешно удалено', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка удаления: {str(e)}', 'danger')
    return redirect(url_for('index'))


# Просмотр деталей блюда
@app.route('/dish/<int:dish_id>', methods=['GET', 'POST'])
@login_required
def view_dish(dish_id):
    dish = Dish.query.get_or_404(dish_id)
    user_rating = Rating.query.filter_by(user_id=current_user.id,
                                         dish_id=dish_id).first()  # Рейтинг текущего пользователя
    avg_rating = db.session.query(func.coalesce(func.avg(Rating.value), 0.0)).filter_by(
        dish_id=dish_id).scalar()  # Средний рейтинг
    comments = db.session.query(Comment, User.username).join(User).filter(Comment.dish_id == dish.id).order_by(
        Comment.created_at.desc()).all()  # Комментарии с именами
    return render_template('dish_detail.html', dish=dish, user_rating=user_rating, comments=comments,
                           avg_rating=avg_rating)


# Оценка блюда
@app.route('/rate_dish/<int:dish_id>', methods=['POST'])
@login_required
def rate_dish(dish_id):
    try:
        rating_value = int(request.form['rating'])
        if not 1 <= rating_value <= 5:  # Проверка диапазона
            raise ValueError("Недопустимое значение оценки")
        existing_rating = Rating.query.filter_by(user_id=current_user.id, dish_id=dish_id).first()
        if existing_rating:  # Обновление существующего рейтинга
            existing_rating.value = rating_value
        else:  # Создание нового рейтинга
            new_rating = Rating(value=rating_value, user_id=current_user.id, dish_id=dish_id)
            db.session.add(new_rating)
        db.session.commit()
        flash('Оценка сохранена', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка: {str(e)}', 'danger')
    return redirect(url_for('view_dish', dish_id=dish_id))


# Панель администратора
@app.route('/admin_panel')
@login_required
def admin_panel():
    if not current_user.is_admin:
        abort(403)
    section = request.args.get('section', 'dashboard')
    if section == 'dashboard':
        stats = {
            'users_count': User.query.count(),
            'dishes_count': Dish.query.count(),
            'comments_count': Comment.query.count()
        }
        return render_template('admin_panel.html', section=section, stats=stats)
    elif section == 'users':
        users = User.query.all()
        return render_template('admin_panel.html', section=section, users=users)
    elif section == 'dishes':
        dishes = Dish.query.all()
        return render_template('admin_panel.html', section=section, dishes=dishes)
    elif section == 'comments':
        comments = Comment.query.all()
        return render_template('admin_panel.html', section=section, comments=comments)
    else:
        return redirect(url_for('admin_panel', section='dashboard'))


# Переключение статуса администратора
@app.route('/toggle_admin/<int:user_id>', methods=['POST'])
@login_required
def toggle_admin(user_id):
    if not current_user.is_admin:
        abort(403)
    try:
        user = User.query.get_or_404(user_id)
        if user.username == 'admin':  # Защита основного админа
            flash('Нельзя изменить права главного администратора', 'danger')
            return redirect(url_for('admin_panel'))
        user.is_admin = not user.is_admin
        db.session.commit()
        flash('Права администратора обновлены', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка: {str(e)}', 'danger')
    return redirect(url_for('admin_panel'))


@app.route('/add_comment/<int:dish_id>', methods=['POST'])
@login_required
def add_comment(dish_id):
    text = request.form.get('comment_text')
    if not text:
        flash('Комментарий не может быть пустым', 'danger')
        return redirect(url_for('view_dish', dish_id=dish_id))
    comment = Comment(text=text, user_id=current_user.id, dish_id=dish_id)
    db.session.add(comment)
    db.session.commit()
    flash('Комментарий добавлен', 'success')
    return redirect(url_for('view_dish', dish_id=dish_id))


# Удаление пользователя
@app.route('/delete_user/<int:user_id>', methods=['POST'])
@login_required
def delete_user(user_id):
    if not current_user.is_admin:
        abort(403)
    user = User.query.get_or_404(user_id)
    if user.username == 'admin':  # Защита основного админа
        flash('Нельзя удалить главного администратора', 'danger')
        return redirect(url_for('admin_panel'))
    if current_user.id == user_id:  # Нельзя удалить себя
        flash('Нельзя удалить самого себя', 'danger')
        return redirect(url_for('admin_panel'))
    try:
        db.session.delete(user)
        db.session.commit()
        flash('Пользователь удален', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Ошибка: {str(e)}', 'danger')
    return redirect(url_for('admin_panel'))


# Выход из системы
@app.route('/logout')
@login_required
def logout():
    logout_user()  # Завершение сессии пользователя
    return redirect(url_for('login'))


# Поиск блюд
@app.route('/search', methods=['GET'])
@login_required
def search():
    query = request.args.get('query', '').strip()  # Получение поискового запроса
    dishes = []
    if query:
        dishes = Dish.query.filter(
            (Dish.name.ilike(f'%{query}%')) | (Dish.ingredients.ilike(f'%{query}%'))
        ).all()  # Поиск по имени или ингредиентам
    return render_template('search.html', dishes=dishes)


# Галерея блюд
@app.route('/gallery')
@login_required
def gallery():
    dishes = Dish.query.filter(Dish.photo is not None).all()  # Выборка блюд с фото
    return render_template('gallery.html', dishes=dishes)


# Запуск приложения и создание базы данных
if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Создание таблиц в базе данных
        admin_user = User.query.filter_by(username='admin').first()
        if not admin_user:  # Создание админа по умолчанию, если его нет
            admin = User(
                username='admin',
                password_hash=generate_password_hash('admin123'),
                is_admin=True,
                avatar='default_avatar.jpg'
            )
            db.session.add(admin)
            db.session.commit()
            print("Создан администратор по умолчанию: admin/admin123")
    app.run(host='0.0.0.0', port=5000, debug=False)  # Запуск сервера
